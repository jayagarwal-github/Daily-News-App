package com.example.dailynews

data class News (
    val title: String,
    val link : String,
    val image_url:String,
)

